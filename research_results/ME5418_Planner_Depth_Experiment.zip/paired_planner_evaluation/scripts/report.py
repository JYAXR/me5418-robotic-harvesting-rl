"""Write the Markdown report from validated CSVs, without specifying outcomes by hand."""
import argparse
import csv
import json
import statistics as st
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--folder", type=Path, default=Path(__file__).resolve().parents[1])
folder = p.parse_args().folder
def rows(f):
    with f.open(newline="") as stream:
        return list(csv.DictReader(stream))
def table(name):
    return rows(folder/"tables"/(name+".csv"))
def dig(name):
    return json.loads((folder/"data"/name).read_text())
allrows=table("all_completed")
eps=table("episodes")
by={(int(r["seed"]),r["method"]):r for r in eps}
old=rows(folder/"audits/earlier_pilot.csv")
for r in old:
    new=by[int(r["seed"]),r["method"]]
    for k in ("steps","success","damage","timeout","travel","peak","reward","contacts"):
        assert r[k]==new[k],(r["seed"],r["method"],k,r[k],new[k])
primary=table("primary_paired")
fixed=table("fixed_beam_paired")
ref=table("astar_pairs")
dqn=dig("dqn_133.json")["summary"]["compact"]
contact=sum(int(r["dqn_contact_steps"])>0 for r in ref)
shorter=sum(float(r["dqn_minus_astar"])<0 for r in ref)
equal=sum(float(r["dqn_minus_astar"])==0 for r in ref)
def results(rs):
    header = ["| Method | Layouts | Success | Damage | Timeout | Steps | Travel | Peak deform. | Return | CPU ms/action | Wall ms/action |",
              "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for v in rs:
        label={"H1":"H1 exact","H3":"H3 exact","H5":"H5 beam 32","H7":"H7 beam 32","H3-B32":"H3 beam 32"}.get(v["method"],v["method"])
        header.append("| "+" | ".join([label]+[v[k] for k in ("episodes","success","damage","timeout")]+[f"{float(v[k]):.{n}f}" for k,n in (("mean_steps",1),("mean_travel",3),("mean_peak",3),("mean_reward",2),("per_action_cpu_ms",2),("per_action_wall_ms",2))])+" |")
    return "\n".join(header)
def avg(k):
    return st.mean(float(r[k]) for r in ref)
def stats(key):
    d=dqn[key]
    return f'{d["success"]}/{d["episodes"]} successful, {d["damage"]} damage, {d["timeout"]} timeouts'
paired_n=int(primary[0]["episodes"])
text=f"""# Results: matched clean layouts

## Main comparison

The table below uses identical layouts for every row, not a separate denominator for each method. {paired_n}/10 planned layouts have all five primary methods available. The archive contains {len(eps)}/60 complete method–layout rollouts across the main experiment and supplement. There are {sum(int(r['steps']) for r in eps):,} executed actions in these traces. Each rollout was evaluated once for comparison; validation repeats are not extra trials.

{results(primary)}

Steps, travel, peak and return are episode means, including timeouts. Peak is normalized to the damage limit. CPU/wall time is per executed decision, including repeated states; neither reset time nor offline learning time is included.

Exhaustive H3 on seed 5420006 is especially expensive: {int(by[5420006,"H3"]["model_calls"]):,} physical transition cache misses, {float(by[5420006,"H3"]["wall_ms"]):.1f} ms per decision averaged over that episode. This is one reason not to read the time column as a monotonic depth curve. Primary H5/H7 prune the search, and repeated identical decisions are cheap.

## Does beam width change the interpretation?

The original H3 is exhaustive; H5/H7 are not. This additional analysis holds the effective cap at 32 across depths. At H1 all eight alternatives fit. H3 beam 32 is an extra run, not a relabelling of the exhaustive H3. DQN, H1, H5 and H7 rows are reused, not new independent observations.

{results(fixed)}

On these ten layouts raising the beam planner's depth to seven did not recover a successful approach. This does **not** exclude success at another depth, beam width, terminal heuristic or compute budget. The engineered waypoint used by the DQN is not supplied to the planner; the outcome is a system-level comparison, not proof that learning beats search under identical guidance.

## Independent context: the 100-layout DQN evaluation

The repository's own evaluator gave **{stats('range')}** on seeds 5420000–5420099, and **{stats('known')}** on the 33 known layouts. Its ten overlapping episode outcomes and physical metrics match the detailed DQN traces exactly. The ten-layout prefix should not replace the 100-layout number. There are no matched planner results for the other 90 layouts.

## What comparison with a feasible global route shows

On the ten accepted scenes the collision-free A* witness reached the goal each time, with zero contact. DQN mean travel was {avg("dqn_travel"):.3f} versus A* {avg("astar_travel"):.3f}; mean steps were {avg("dqn_steps"):.1f} versus {avg("astar_steps"):.1f}. The DQN made contact on {contact}/10 layouts. Its path was strictly shorter on {shorter}/10, tied on {equal}/10 and longer on {10-shorter-equal}/10. Distances are in normalized workspace units. These data show **no average path-length advantage from the learned policy** in this subset. Without a no-contact ablation, an individual shorter path is not evidence that contact caused the improvement. A* success is conditional on scene admission, not an unbiased global-planner success rate.

## Why might a deeper search still time out?

![Actual DQN and H7 trajectories on the first layout](example.png)

The figure uses recorded end-effector positions over the original resting branch shapes. Repeated actions at the same position are drawn on top of one another; they still count toward the 200-step limit.

On seed 5420000 near the first gate, at (0.23803, 0.50155), independently enumerating all depth-three continuations yields a best score of zero for both rightward first actions. The best score starting with either upward move is about −0.000000238; the downward alternatives score lower still. Thus not advancing can be locally competitive under this finite-horizon reward. This is one diagnosed state, not a proof that all failures have the same cause. We did not independently brute-force H5 or H7, nor optimize planner-specific terminal values.

## Audit and limits

- All {len(old)} available outcomes of the earlier pilot reproduce on steps, success, damage, timeout, travel, peak deformation, cumulative reward and contact count. Timing is intentionally not required to be identical.
- See [coverage](tables/coverage.csv), [per-layout metrics](tables/episodes.csv), [per-seed A* comparison](tables/astar_pairs.csv) and [audits](audits/). Missing cells, if any, are not scored as timeouts.
- This is a deterministic, previously used evaluation range, a single checkpoint and one layout family. It is not a blind robustness benchmark and does not test execution noise. There is no matched time-budget, equal-feature ablation, training-cost comparison, real-robot claim or state-of-the-art optimal-planning claim.
"""
(folder/"RESULTS.md").write_text(text,encoding="utf-8")
cn = ["# 组内速读：规划深度对照", "",
      "问题：把规划器从只看一步改成看多步，是否能在相同枝条布局、相同移动和损伤限制下，追上已经训练好的紧凑几何引导 DQN？这次只做评估，没有重新训练，也没有增大奖励或惩罚。",
      "", f"主表严格使用同一批 {paired_n} 个布局。一次试验 = 一种方法完成一个布局；60 次方法×布局并不等于 60 个不同布局。",
      "", "| 方法 | 成功 | 损伤 | 超时 | 每步平均决策用时（毫秒） |",
      "|---|---:|---:|---:|---:|"]
for v in primary:
    name={"H1":"H=1，穷举","H3":"H=3，穷举","H5":"H=5，每层保留32条","H7":"H=7，每层保留32条","DQN":"紧凑几何引导 DQN"}[v["method"]]
    cn.append(f"| {name} | {v['success']}/{v['episodes']} | {v['damage']} | {v['timeout']} | {float(v['per_action_wall_ms']):.2f} |")
cn.extend(["", "另外用 H=3、每层保留32条重跑了相同的10个布局。这项补充对照为 0/10 成功、0 损伤、10 次步数耗尽。它是事后增加的，不替代 H=3 穷举。",
    "", "**不要混用三个数字：** 10/10 是 DQN 在规划器对比的十个布局的表现；81/100 是它在完整的既有评估布局库上的表现（其中含这十个）；31/33 是它在熟悉布局上的表现。规划器没有跑满100个布局，不能写成‘DQN 81% 对规划器 0%’。",
    "", f"**也不要写成更短或更安全。** 被接纳的场景本来就有 A* 验证的无碰撞路线。DQN 平均走 {avg('dqn_travel'):.3f}，A* 平均走 {avg('astar_travel'):.3f}（单位工作区）；只有 {shorter}/10 条 DQN 路线更短。规划器超时不等于造成损伤。",
    "", "**结论边界：** 这是干净、确定性的多路线仿真，DQN 具有人工设计的局部路线引导，规划器没有终端价值或同等引导。耗时包含缓存、受并发影响，不是通用加速倍数。尚未完成有噪声条件下的同场配对，不能据此宣称随机环境鲁棒性。",
    "", "**怎么给老师复核：** 英文实验方法见 README.md；结果和轨迹图见 RESULTS.md；每个种子、每一步的原始数据见 data/episodes/。按 README 的命令可以先快速核对表格，再选择某场回放，或在新目录重新跑全套实验。"])
(folder/"SUMMARY_ZH.md").write_text("\n".join(cn)+"\n",encoding="utf-8")
print(f"PASS: {len(old)} historical pilot rows match on eight physical/outcome fields; wrote results from CSV.")

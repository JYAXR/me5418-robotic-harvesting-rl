"""Verify archived file hashes without loading models or changing files."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def verify():
    manifest = json.loads((HERE / "MANIFEST.json").read_text())
    for entry in manifest["files"]:
        path = HERE / entry["path"]
        if path.stat().st_size != entry["bytes"]:
            raise ValueError(f"Size mismatch: {entry['path']}")
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError(f"Hash mismatch: {entry['path']}")
    print(f"Verified {len(manifest['files'])} archived files.")


if __name__ == "__main__":
    verify()
